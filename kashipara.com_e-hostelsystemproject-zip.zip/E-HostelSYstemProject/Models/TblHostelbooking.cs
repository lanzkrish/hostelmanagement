
namespace E_HostelSYstemProject.Models
{
    using System;
    using System.Collections.Generic;
    
    public partial class TblHostelbooking
    {
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string email { get; set; }
        public decimal mobile { get; set; }
        public string Standerd { get; set; }
        public System.DateTime dob { get; set; }
        public string description { get; set; }
    }
}
