
namespace E_HostelSYstemProject.Models
{
    using System;
    using System.Collections.Generic;
    
    public partial class TblContact
    {
        public string name { get; set; }
        public string email { get; set; }
        public string subject { get; set; }
        public string message { get; set; }
    }
}
