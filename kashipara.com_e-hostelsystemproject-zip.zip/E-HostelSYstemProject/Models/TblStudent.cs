
namespace E_HostelSYstemProject.Models
{
    using System;
    using System.Collections.Generic;
    
    public partial class TblStudent
    {
        public string fullName { get; set; }
        public string gender { get; set; }
        public string email { get; set; }
        public decimal mobile { get; set; }
        public string pass { get; set; }
    }
}
