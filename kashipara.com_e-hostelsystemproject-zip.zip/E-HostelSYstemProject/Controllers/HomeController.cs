﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using E_HostelSYstemProject.Models;
using System.Data.Entity;

namespace E_HostelSYstemProject.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult About()
        {
            return View();
        }
        public ActionResult Services()
        {
            return View();
        }
        public ActionResult Gallery()
        {
            return View();
        }
        public ActionResult Info()
        {
            return View();
        }
        public ActionResult Contact()
        {
            return View();
        }
        public ActionResult Registration()
        {
            return View();
        }
        public ActionResult Booking()
        {
            return View();
        }
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Contact(TblContact tblContact)
        {
            using(EHostelDataEntities entities=new EHostelDataEntities())
            {
                if(ModelState.IsValid)
                {
                    entities.TblContacts.Add(tblContact);
                    entities.SaveChanges();
                    ViewBag.Success = "Feedback Send Sucessfully";
                    ModelState.Clear();
                }
            }
            return View(tblContact);
        }
        [HttpPost]
        public ActionResult Registration(TblStudent tblStudent)
        {
            using (EHostelDataEntities entities = new EHostelDataEntities())
            {
                if (ModelState.IsValid)
                {
                    entities.TblStudents.Add(tblStudent);
                    entities.SaveChanges();
                    ViewBag.Sucess = "Registration Sucessfully";
                    ModelState.Clear();
                }
            }
            return View(tblStudent);
            
        }
        [HttpPost]
        public ActionResult Booking(TblHostelbooking tblHostelbooking)
        {
            using (EHostelDataEntities entities = new EHostelDataEntities())
            {
                if (ModelState.IsValid)
                {
                    entities.TblHostelbookings.Add(tblHostelbooking);
                    entities.SaveChanges();
                    ViewBag.Sucess = "Your Booking Confirm Sucessfully";
                    ModelState.Clear();
                }
            }
            return View(tblHostelbooking);
        }
        [HttpPost]
        public ActionResult Login(TblStudent tblStudent)
        {
            using(EHostelDataEntities entities=new EHostelDataEntities())
            {
                var obj = entities.TblStudents.Where(a => a.email.Equals(tblStudent.email) && a.pass.Equals(tblStudent.pass)).FirstOrDefault();
                if (obj != null)
                {
                    //Session["UserID"] = obj.UserId.ToString();
                    //Session["UserName"] = obj.email.ToString();
                    return RedirectToAction("Home/Booking");
                }
            }
            return View(tblStudent);
        }
    }
}